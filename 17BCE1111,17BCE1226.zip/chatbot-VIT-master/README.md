# chatbot-VIT
Chatbot on VIT Chennai
For usin the chatbot on webite you can directly insert he following code inside the body of your HTML code of your website:

 <script src="https://account.snatchbot.me/script.js"></script><script>window.sntchChat.Init(87969)</script> 
